print('21')
print('2')

import os

print(os.listdir())