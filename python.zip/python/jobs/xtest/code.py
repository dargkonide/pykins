from time import sleep

for n in range(int(count)):
    print(n)
    sleep(0.1)